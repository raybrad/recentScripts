#!/bin/sh

#for k in 0 30 50 300 500 530 550 600 640 740
 for k in  550 600 640 740
#for k in  640
do    
    #awk -v var="dos_h.$k.dat" '{print>(NR>(n/2)?2:1)}' n="$(wc -l <dos_h.$k.dat)" dos_h.$k.dat

    max1=`awk 'BEGIN {max = 0 } {if ($2>max) {max=$2}} END {print max}' dos_h.${k}.dat1`
    max2=`awk 'BEGIN {max = 0 } {if ($2>max) {max=$2}} END {print max}' dos_h.${k}.dat2`
    
    occ1=`awk 'BEGIN {max = 0 } {if ($3>max) {max=$3}} END {print max}' ../../occ/${k}fs.occ`
    occ2=`awk 'BEGIN {max = 0 } {if ($3>max) {max=$3}} END {print max}' ../../empt/${k}fs.empt`
    
    #cut1=`python -c "print $max1*$occ1/2.0"`
    #cut2=`python -c "print $max2*$occ2/2.0"`
    cut1=`python -c "print $max1*$occ1/4.0"`
    cut2=`python -c "print $max2*$occ2/4.0"`

    echo $max1
    echo $occ1
    echo $cut1
    echo '' 
    echo $max2
    echo $occ2
    echo $cut2
    echo '' 

    

    awk -v var="$cut1" '(NR>1) && ($2 < var ) ' dos_h.${k}.dat1 >dos_h.${k}.tmp1
    mv dos_h.${k}.tmp1 dos_h.${k}.dat1
    
    awk -v var="$cut2" '(NR>1) && ($2 < var ) ' dos_h.${k}.dat2 >dos_h.${k}.tmp2
    mv dos_h.${k}.tmp2 dos_h.${k}.dat2
done

