#!/bin/sh
for k in $(seq 60000 1000 74000 )
do
    # cd ${k}fs
    # dp_dos -w dos_h.out dos_h.dat
    # cd ..
    #cp -r lode ${k}fs/lode
    paste ../diagMO.0 ../diagMO.${k}>${k}.dat
    #rm ${k}fs/*dat ${k}fs/*out ${k}fs/charges.bin ${k}fs/*gen
done
