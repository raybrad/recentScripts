#!/bin/sh
for k in $(seq 610 10 740)
do
    # cd ${k}fs
    # dp_dos -w dos_h.out dos_h.dat
    # cd ..
    #cp -r lode ${k}fs/lode
    cp ~/Projects/auh2/basic/auh2-d3.6/timeCW2d-1/${k}fs/dos_h.dat  dos_h.${k}.dat
    #rm ${k}fs/*dat ${k}fs/*out ${k}fs/charges.bin ${k}fs/*gen
done
