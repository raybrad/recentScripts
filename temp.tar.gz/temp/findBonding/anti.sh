#!/bin/sh
for k in $(seq $1 $2 $3)
do
       sed -n '1,300p' ${k}fs/dos_h.dat|awk 'BEGIN {max = 0;linum=0;col1=0} {if ($2>max) {max=$2; linum=NR;col1=$1}} END {print col1}' >> bond.dat 
       sed -n '300,$p' ${k}fs/dos_h.dat|awk 'BEGIN {max = 0;linum=0;col1=0} {if ($2>max) {max=$2; linum=NR;col1=$1}} END {print col1}' >> antibond.dat 
done

