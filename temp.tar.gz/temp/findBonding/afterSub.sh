#!/bin/sh
startime=0
interval=50
endtime=100
line=300
#./dos.sh $startime  $interval $endtime 
# sleep 1
# ./MO.sh $startime  $interval $endtime 
#sleep 1
#./anti.sh $startime $interval $endtime  $line
#sleep 1
nOrbs=722
tb=0
te=100
tg=50
#./getMOpoint $nOrbs $tb $te $tg >log   
sleep 1
grep -iw 'fcountera' log >fcountera.dat
grep -iw 'fcounterb' log >fcounterb.dat
sleep 1
./getOcc $nOrbs $tb $te $tg 
