#!/bin/sh
startime=0
interval=10
endtime=300
lineSep=84
intInfile=1
cp tdCoord.data 0fs/Au-h2.xyz
sleep 1
# $1 interval  $2 endtime
./cpDir.sh  $interval $endtime
sleep 1
#$1 startime
#$2 time interval 
#$3 endtime 
#$4 atom number
#$5 interval in tdCoord.data
./sed.sh $startime $interval $endtime $lineSep $intInfile
sleep 1
#$1 startime $2 interval  $3 endtime
./cpXYZ.sh $startime  $interval $endtime
sleep 1
./gen.sh $startime $interval $endtime
