#!/bin/sh
for k in $(seq $1 $2 $3)
do
      cd  ${k}fs   && nohup dftb+<dftb_in.hsd>out.log & 
done
