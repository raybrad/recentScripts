#!/bin/sh
for k in $(seq $1 $2 $3)
do
      paste ${k}fs/lode/diagMO.0 ${k}fs/lode/MOcoeff.dat > ${k}fs/lode/MOcoeff.ev  
done
