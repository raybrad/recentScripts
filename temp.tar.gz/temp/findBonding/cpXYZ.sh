#!/bin/sh
for k in $(seq $1 $2 $3 ) 
do
     cp ${k}fs/Au-h2.xyz  ${k}fs/lode/AuSphere-H2.xyz
done
