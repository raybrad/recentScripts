#!/bin/sh
for k in $(seq $1 $1 $2 ) 
do
     cp -r 0fs  ${k}fs
done
