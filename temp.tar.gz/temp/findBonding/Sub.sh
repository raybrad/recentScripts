#!/bin/sh
startime=0
interval=10
endtime=300
./dftb.sh $startime  $interval $endtime 
./lode.sh  $startime $interval $endtime 
