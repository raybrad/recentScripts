#!/bin/sh
for k in $(seq $1 $2 $3)
do
       dp_dos -w ${k}fs/dos_h.out ${k}fs/dos_h.dat &
done
