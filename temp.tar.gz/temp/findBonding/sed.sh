#!/bin/sh
for i in $(seq $1 $2 $3) 
do
    k=$((i/$5*$4+1))
    j=$((($i/$5+1)*$4))
    sed -i -n "${k},${j}p" ${i}fs/Au-h2.xyz 
done
#$1 startime
#$2 time interval 
#$3 endtime 
#$4 atom number
#$5 interval in tdCoord.data
