#!/bin/sh
for k in $(seq $1 $2 $3) 
do 
     xyz2gen ${k}fs/Au-h2.xyz
done
